from flask import Flask, request, render_template, redirect, url_for, abort, flash

app = Flask(__name__)
app.secret_key = 'une cle(token) : grain de sel(any random string)'

from flask import session, g
import pymysql.cursors

def get_db():
    if 'db' not in g:
        g.db =  pymysql.connect(
            host="serveurmysql",                 # à modifier
            user="agaiffe2",                     # à modifier
            password="mdp",                # à modifier
            database="BDD_agaiffe2",        # à modifier
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )
    return g.db



@app.route('/')
def show_layout():
    return render_template('layout.html')


if __name__ == '__main__':
    app.run()

@app.route('/')
@app.route('/recolte/show')
def show_recolte():
    mycursor = get_db().cursor()
    sql=''' SELECT * Id_Récolte AS id,  Quantitée_récoltée AS Recolte, Id_Semaine AS semaine, Id_produit AS produit, Id_Maraicher AS maraicher,
    FROM semaine, 
    ORDER BY id;'''
    mycursor.execute(sql)
    Récolte = mycursor.fetchall()
    return render_template('recolte/show_recolte.html', Récolte=Récolte)

